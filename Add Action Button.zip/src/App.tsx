import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Benefits } from "./components/Benefits";
import { Program } from "./components/Program";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Benefits />
      <Program />
      <Footer />
    </div>
  );
}