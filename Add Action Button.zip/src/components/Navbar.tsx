import { Dumbbell } from "lucide-react";

export function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-8 h-8 text-orange-600" />
            <span className="text-xl text-gray-900">FitHome Academy</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#benefits" className="text-gray-700 hover:text-orange-600 transition-colors">
              Benefits
            </a>
            <a href="#program" className="text-gray-700 hover:text-orange-600 transition-colors">
              Program
            </a>
            <a 
              href="https://www.facebook.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-orange-600 text-white px-6 py-2 rounded-full hover:bg-orange-700 transition-colors"
            >
              Get Started
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}