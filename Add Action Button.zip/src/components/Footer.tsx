import { Dumbbell } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Dumbbell className="w-8 h-8 text-orange-600" />
              <span className="text-xl text-white">FitHome Academy</span>
            </div>
            <p className="text-gray-400 mb-4">
              Official Les Mills affiliate. Access world-class fitness programs including 
              Combat, HIIT, Strength Training, Dance, and Yoga - all from home.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#benefits" className="hover:text-orange-600 transition-colors">
                  Benefits
                </a>
              </li>
              <li>
                <a href="#program" className="hover:text-orange-600 transition-colors">
                  Program
                </a>
              </li>
              <li>
                <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer" className="hover:text-orange-600 transition-colors">
                  Enroll Now
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="text-center text-gray-400 text-sm">
            <p>&copy; 2025 FitHome Academy. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}