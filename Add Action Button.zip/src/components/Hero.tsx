import { ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1728378146814-173087668c62?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxISUlUJTIwdHJhaW5pbmclMjBob21lfGVufDF8fHx8MTc2NTY0MjAyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Home fitness training"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/40"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h1 className="text-white mb-6 max-w-4xl mx-auto">
          Transform Your Body With World-Class Fitness Programs
        </h1>
        <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
          Join thousands training with Les Mills at home. Combat, HIIT, Strength, Dance, and Yoga - 
          All the variety you need to stay motivated and get results.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="https://www.facebook.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-orange-600 text-white px-8 py-4 rounded-full hover:bg-orange-700 transition-all transform hover:scale-105 flex items-center gap-2 shadow-lg"
          >
            Start Training Today
            <ArrowRight className="w-5 h-5" />
          </a>
          
          <a
            href="#benefits"
            className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-full hover:bg-white/20 transition-colors border border-white/30"
          >
            Learn More
          </a>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 max-w-3xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="text-4xl text-orange-500 mb-2">10,000+</div>
            <div className="text-gray-200">Active Students</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="text-4xl text-orange-500 mb-2">6+</div>
            <div className="text-gray-200">Program Types</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="text-4xl text-orange-500 mb-2">24/7</div>
            <div className="text-gray-200">On-Demand Access</div>
          </div>
        </div>
      </div>
    </section>
  );
}