import { Check, PlayCircle, BookOpen, Users } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const modules = [
  {
    name: "Combat & Cardio",
    image: "https://images.unsplash.com/photo-1651707999616-be901bcc97fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3hpbmclMjBmaXRuZXNzJTIwd29ya291dHxlbnwxfHx8fDE3NjU2NDIwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    features: [
      "Boxing & kickboxing combos",
      "High-energy cardio bursts",
      "Full-body conditioning",
      "Stress relief & empowerment"
    ]
  },
  {
    name: "HIIT & Strength",
    image: "https://images.unsplash.com/photo-1591291621164-2c6367723315?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJlbmd0aCUyMHRyYWluaW5nJTIwaG9tZXxlbnwxfHx8fDE3NjU2NDIwMjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    features: [
      "Intense interval training",
      "Weight & bodyweight exercises",
      "Muscle building routines",
      "Fat-burning workouts"
    ]
  },
  {
    name: "Dance & Yoga",
    image: "https://images.unsplash.com/photo-1758599879728-d7079db6505b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2dhJTIwYmFsYW5jZSUyMGZsZXhpYmlsaXR5fGVufDF8fHx8MTc2NTY0MjAyM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    features: [
      "Dance fitness routines",
      "Yoga & flexibility work",
      "Mind-body connection",
      "Recovery & mobility"
    ]
  }
];

const courseIncludes = [
  {
    icon: PlayCircle,
    title: "200+ Video Workouts",
    description: "Follow along with expert instructors in HD quality Les Mills classes"
  },
  {
    icon: BookOpen,
    title: "Structured Programs",
    description: "12-week progressive training plans for every fitness goal"
  },
  {
    icon: Users,
    title: "Global Community",
    description: "Join thousands training with Les Mills worldwide"
  }
];

export function Program() {
  return (
    <section id="program" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gray-900 mb-4">
            What's Included in the Program
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Complete access to Les Mills' most popular fitness programs
          </p>
        </div>

        {/* Course Includes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {courseIncludes.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="text-center"
              >
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Icon className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-gray-900 mb-2">
                  {item.title}
                </h3>
                <p className="text-gray-600">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Training Modules */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {modules.map((module, index) => (
            <div
              key={index}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-gray-100"
            >
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src={module.image}
                  alt={module.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-gray-900 mb-4">
                  {module.name}
                </h3>
                <ul className="space-y-2">
                  {module.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-gray-600">
                      <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-2xl p-12 text-center text-white">
          <h3 className="mb-4">
            Ready to Transform Your Fitness?
          </h3>
          <p className="text-xl mb-8 text-orange-100 max-w-2xl mx-auto">
            Join the global Les Mills community and access world-class workouts. 
            Combat, HIIT, Strength, Dance, Yoga - everything you need in one place.
          </p>
          <a
            href="https://www.facebook.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white text-orange-600 px-8 py-4 rounded-full hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg"
          >
            Enroll in the Course Today
          </a>
        </div>
      </div>
    </section>
  );
}