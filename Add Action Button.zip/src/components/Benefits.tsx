import { Zap, Home, TrendingUp, Users, Shield, Heart } from "lucide-react";

const benefits = [
  {
    icon: Zap,
    title: "Multiple Training Styles",
    description: "Combat, HIIT, Strength, Dance, Yoga, and more. Never get bored with diverse workouts."
  },
  {
    icon: Heart,
    title: "Cardio & Strength Combined",
    description: "Build endurance and muscle with scientifically designed Les Mills programs."
  },
  {
    icon: Home,
    title: "Train Anywhere",
    description: "Access world-class fitness programs from your living room. No gym membership needed."
  },
  {
    icon: TrendingUp,
    title: "Progressive Programs",
    description: "From beginner to advanced. Each program adapts to your fitness level."
  },
  {
    icon: Users,
    title: "Expert Instructors",
    description: "Learn from certified Les Mills trainers with decades of experience."
  },
  {
    icon: Shield,
    title: "Proven Results",
    description: "Join millions worldwide who have transformed their bodies with Les Mills."
  }
];

export function Benefits() {
  return (
    <section id="benefits" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gray-900 mb-4">
            Why Choose Our Training Program?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Everything you need to build strength and muscle from home
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl p-8 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-orange-600" />
                </div>
                <h3 className="text-gray-900 mb-3">
                  {benefit.title}
                </h3>
                <p className="text-gray-600">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <a
            href="https://www.facebook.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-orange-600 text-white px-8 py-4 rounded-full hover:bg-orange-700 transition-all transform hover:scale-105 shadow-lg"
          >
            Start Your Transformation
          </a>
        </div>
      </div>
    </section>
  );
}